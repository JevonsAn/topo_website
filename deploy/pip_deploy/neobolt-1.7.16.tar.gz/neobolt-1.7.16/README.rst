========================================
Neobolt: Neo4j Bolt connector for Python
========================================

Neobolt is a Bolt connector library for Python.
It is generally intended for use by a higher level `driver <https://github.com/neo4j/neo4j-python-driver/>`_.
